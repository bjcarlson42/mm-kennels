﻿using System.Collections.Generic;

namespace MMKennels
{
	public interface IDatabase
	{
		ICollection<Animal> Animals { get; }
		ICollection<Cage> Cages { get; }
	}
}