﻿namespace MMKennels
{
	public class Animal
	{
		public Animal(string name, int weight, int startDay, int numDays)
		{
			Name = name;
			Weight = weight;
			StartDay = startDay;
			NumDays = numDays;
		}
		
		public string Name { get; }
		public int Weight { get; }
		public int StartDay { get; }
		public int NumDays { get; }
		public Cage AssignedCage { get; set; }
	}
}