﻿using System.Collections.Generic;

namespace MMKennels
{
	public interface IScheduler
	{
		AnimalResult GetAnimal(string name);
		IEnumerable<CageResult> GetDay(int day);
		CageResult ScheduleAnimal(string name, int weight, int startDay, int numDays);
	}
}