﻿namespace MMKennels
{
	public class Cage
	{
		public Cage(int id, int minWeight, int maxWeight)
		{
			Id = id;
			MinWeight = minWeight;
			MaxWeight = maxWeight;
		}

		public int Id { get; }
		public int MinWeight { get; }
		public int MaxWeight { get; }
	}
}