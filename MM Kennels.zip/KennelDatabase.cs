﻿using System.Collections.Generic;

namespace MMKennels
{
	public class KennelDatabase : IDatabase
	{
		public ICollection<Animal> Animals { get; } = new List<Animal>();
		public ICollection<Cage> Cages { get; } = new List<Cage>();
	}
}