﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MMKennels
{
	public class Scheduler : IScheduler
	{
		private readonly IDatabase _database;

		public Scheduler(IDatabase database)
		{
			_database = database;
		}

		public AnimalResult GetAnimal(string name)
		{
			throw new NotImplementedException();
		}

		public IEnumerable<CageResult> GetDay(int day)
		{
			throw new NotImplementedException();
		}

		public CageResult ScheduleAnimal(string name, int weight, int startDay, int numDays)
		{
			throw new NotImplementedException();
		}
	}
}